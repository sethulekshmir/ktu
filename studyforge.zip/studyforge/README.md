# StudyForge

Syllabus in → web-researched notes, previous-year questions, scoring topics out.
React (Vite) frontend + a Vercel serverless function (`api/generate.js`) that calls the Claude API with web search. Your API key stays on the server.

## Run locally
```bash
npm install
npm i -g vercel
cp .env.example .env      # add your ANTHROPIC_API_KEY
vercel dev                # runs frontend + /api together
```

## Deploy (public link)
1. Push this folder to GitHub.
2. Import the repo at vercel.com → New Project (framework: Vite).
3. Add environment variable `ANTHROPIC_API_KEY` (from console.anthropic.com).
4. Deploy. Share the URL.

## Notes
- Each "Generate" makes 3 API calls with web search, so it costs money. Set a spend limit in the Anthropic console.
- The in-memory rate limit (12 requests/IP/hour) resets on cold starts; use Vercel KV/Upstash for a stricter one.
- Vercel Hobby functions may time out at 60s; if so, upgrade or reduce `max_uses` in `api/generate.js`.

- PDF uploads are sent as base64 through the serverless function. Vercel limits request bodies to about 4.5 MB, so the app allows up to 3 PDFs / about 3 MB total. For bigger files, upload to storage (Vercel Blob, S3) and pass a URL instead.
