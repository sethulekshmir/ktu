// Vercel serverless function. Keeps your API key on the server.
const MODEL = "claude-sonnet-5-5";
const hits = new Map(); // naive per-IP rate limit (resets on cold start)
const LIMIT = 12, WINDOW = 60 * 60 * 1000;

const base =
  "Output plain Markdown only (## for modules, ### for sub-topics, - bullets, **bold** key terms). No tables, no HTML, no preamble.";

function prompts(b) {
  const ctx = `Department: ${b.dept || "not specified"}
Semester: ${b.sem || "not specified"}
Subject: ${b.subject || "not specified"}
Exam/University: ${b.exam || "not specified"}

SYLLABUS:
${b.syllabus}`;
  return {
    notes: `You are an expert exam tutor. Search the web for reliable study material (university notes, open courseware, textbooks' public summaries) and prepare ${b.depth || "detailed"} study notes covering EVERY module and topic of the syllabus below, in syllabus order. For each topic: clear explanation, key points, formulas/algorithms where relevant, a short example, a one-line memory tip. End each module with a "Quick revision" list. Paraphrase in your own words; never copy long passages. ${base}\n\n${ctx}`,
    pyq: `You are an exam-paper analyst. Search the web for previous-year question papers for this subject/university/semester. Module by module, list questions in the style: ${b.marks || "2, 5 and 10 mark mix"}. Tag each [Found in past paper] only if a search result actually shows it, otherwise [Likely – based on pattern]. Give marks and a one-line answer hint. Never invent a year or paper code. ${base}\n\n${ctx}`,
    imp: `You are a scoring strategist. Using web research and the syllabus below, rank topics by marks potential: ## High-priority, ## Medium-priority, ## Low-priority. For each give the topic, why it scores, and a suggested share of study time. End with ## Last-48-hours plan and ## Answer-writing tips. ${base}\n\n${ctx}`,
  };
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  if (!process.env.ANTHROPIC_API_KEY)
    return res.status(500).json({ error: "Server is missing ANTHROPIC_API_KEY" });

  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0] || "unknown";
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW);
  if (recent.length >= LIMIT) return res.status(429).json({ error: "Rate limit reached. Try again later." });
  hits.set(ip, [...recent, now]);

  const b = req.body || {};
  const pdfs = (Array.isArray(b.pdfs) ? b.pdfs : []).filter((p) => p && typeof p.data === "string").slice(0, 3);
  const syl = (b.syllabus || "").trim();
  if ((syl.length < 10 && !pdfs.length) || syl.length > 8000)
    return res.status(400).json({ error: "Add a syllabus (10–8000 characters) or attach a PDF." });
  if (pdfs.reduce((n, p) => n + p.data.length, 0) > 4_200_000)
    return res.status(413).json({ error: "PDFs are too large (about 3 MB total max)." });
  b.syllabus = syl || "(No pasted syllabus. Extract it from the attached PDF.)";
  let prompt = prompts(b)[b.kind];
  if (!prompt) return res.status(400).json({ error: "Unknown kind" });
  if (pdfs.length)
    prompt =
      "The attached PDF(s) are the user's own material (syllabus, notes or past papers). Treat them as the primary source: if the pasted syllabus is empty, extract the syllabus from them; base the content on them, adding web research only to fill gaps. Any question that appears in an attached past paper must be tagged [From uploaded paper].\n\n" +
      prompt;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 6000,
        tools: [{ type: "web_search_20250305", name: "web_search", max_uses: 5 }],
        messages: [{
          role: "user",
          content: [
            ...pdfs.map((p) => ({ type: "document", source: { type: "base64", media_type: "application/pdf", data: p.data } })),
            { type: "text", text: prompt },
          ],
        }],
      }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.error?.message || "Upstream error" });

    const text = (data.content || []).filter((c) => c.type === "text").map((c) => c.text).join("");
    const seen = new Set();
    const sources = [];
    for (const c of data.content || [])
      for (const ci of c.citations || [])
        if (ci.url && !seen.has(ci.url)) { seen.add(ci.url); sources.push({ url: ci.url, title: ci.title || ci.url }); }

    res.status(200).json({ text, sources });
  } catch (e) {
    res.status(500).json({ error: "Request failed" });
  }
}
