import { useState } from "react";

const DEPTS = ["Computer Science & Engineering","Information Technology","Electronics & Communication","Electrical & Electronics","Mechanical Engineering","Civil Engineering","Chemical Engineering","AI & Data Science","Other"];
const SEMS = [1,2,3,4,5,6,7,8].map((n) => `Semester ${n}`);
const TABS = { notes: "Notes", pyq: "Previous-year questions", imp: "Scoring topics" };

const esc = (s) => s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const inline = (s) => esc(s).replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/`(.+?)`/g,"<code>$1</code>").replace(/\*(.+?)\*/g,"<em>$1</em>");
function md(t) {
  const out = []; let list = false;
  t.split("\n").forEach((l) => {
    let m;
    if ((m = l.match(/^\s*[-*•]\s+(.*)/))) { if (!list) { out.push("<ul>"); list = true; } out.push(`<li>${inline(m[1])}</li>`); return; }
    if (list) { out.push("</ul>"); list = false; }
    if ((m = l.match(/^#{1,2}\s+(.*)/))) out.push(`<h2>${inline(m[1])}</h2>`);
    else if ((m = l.match(/^#{3,6}\s+(.*)/))) out.push(`<h3>${inline(m[1])}</h3>`);
    else if (l.trim()) out.push(`<p>${inline(l)}</p>`);
  });
  if (list) out.push("</ul>");
  return out.join("");
}

export default function App() {
  const [f, setF] = useState({ dept: "", sem: "", subject: "", exam: "", syllabus: "", depth: "detailed", marks: "2, 5 and 10 mark mix" });
  const [res, setRes] = useState({ notes: null, pyq: null, imp: null });
  const [tab, setTab] = useState("notes");
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function run(kind) {
    try {
      const r = await fetch("/api/generate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...f, kind, pdfs: files.map(({ name, data }) => ({ name, data })) }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Failed");
      setRes((p) => ({ ...p, [kind]: d }));
    } catch (e) {
      setRes((p) => ({ ...p, [kind]: { text: "", sources: [], error: `${TABS[kind]} failed: ${e.message}` } }));
    }
  }

  function readFile(file) {
    return new Promise((ok, no) => {
      const r = new FileReader();
      r.onload = () => ok({ name: file.name, size: file.size, data: String(r.result).split(",")[1] });
      r.onerror = no;
      r.readAsDataURL(file);
    });
  }

  async function addPdfs(e) {
    const picked = [...e.target.files]; e.target.value = "";
    const pdfs = picked.filter((x) => x.type === "application/pdf" || x.name.toLowerCase().endsWith(".pdf"));
    if (pdfs.length < picked.length) setMsg("Only PDF files are supported.");
    const all = [...files, ...(await Promise.all(pdfs.map(readFile)))];
    if (all.length > 3) { setMsg("You can attach up to 3 PDFs."); return; }
    if (all.reduce((n, x) => n + x.size, 0) > 3 * 1024 * 1024) { setMsg("PDFs are too large (about 3 MB total max)."); return; }
    setFiles(all);
  }

  async function go() {
    if (f.syllabus.trim().length < 10 && !files.length) { setMsg("Paste a syllabus or attach a PDF first."); return; }
    setBusy(true); setMsg("Researching the web and writing your study pack… this can take up to a minute.");
    setRes({ notes: null, pyq: null, imp: null });
    await Promise.all(["notes", "pyq", "imp"].map(run));
    setBusy(false); setMsg("Done.");
  }

  function download() {
    const text = `# ${f.subject || "Study pack"}\n\n` + Object.keys(TABS).map((k) => `# ${TABS[k]}\n\n${res[k]?.text || ""}`).join("\n\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "text/markdown" }));
    a.download = "study-pack.md"; a.click(); URL.revokeObjectURL(a.href);
  }

  const cur = res[tab];
  return (
    <div className="wrap">
      <h1>StudyForge</h1>
      <p className="sub">Paste a syllabus → web-researched notes, previous-year questions and high-scoring topics.</p>

      <div className="card">
        <div className="row">
          <div><label>Department</label><select value={f.dept} onChange={set("dept")}><option value="">Select department</option>{DEPTS.map((d) => <option key={d}>{d}</option>)}</select></div>
          <div><label>Semester</label><select value={f.sem} onChange={set("sem")}><option value="">Select semester</option>{SEMS.map((s) => <option key={s}>{s}</option>)}</select></div>
        </div>
        <div className="row">
          <div><label>Subject / course</label><input value={f.subject} onChange={set("subject")} placeholder="e.g. Data Structures" /></div>
          <div><label>Exam / university</label><input value={f.exam} onChange={set("exam")} placeholder="e.g. KTU, CBSE, GATE" /></div>
        </div>
        <label>Syllabus</label>
        <textarea value={f.syllabus} onChange={set("syllabus")} placeholder="Paste modules / units / topics here…" />
        <label style={{ marginTop: 14 }}>Attach PDFs (optional)</label>
        <input type="file" accept="application/pdf" multiple onChange={addPdfs} />
        <div className="status" style={{ marginTop: 4 }}>Syllabus, notes or past question papers. Up to 3 PDFs, about 3 MB total.</div>
        {files.length > 0 && <ul className="files">{files.map((x, i) => <li key={x.name + i}>{x.name} <button onClick={() => setFiles(files.filter((_, j) => j !== i))}>Remove</button></li>)}</ul>}
        <div className="row" style={{ marginTop: 14 }}>
          <div><label>Note depth</label><select value={f.depth} onChange={set("depth")}><option value="concise">Concise revision notes</option><option value="detailed">Detailed study notes</option><option value="in-depth, example-rich">In-depth with examples</option></select></div>
          <div><label>Question style</label><select value={f.marks} onChange={set("marks")}><option>2, 5 and 10 mark mix</option><option>Short answer (2–3 marks)</option><option>Long answer (10+ marks)</option><option>MCQ / objective</option></select></div>
        </div>
        <div className="actions"><button className="pri" onClick={go} disabled={busy}>Generate study pack</button><span className="status">{msg}</span></div>
        <div className="note">Content is AI-generated using web search. Always verify questions and facts against your official syllabus, textbooks and past papers.</div>
      </div>

      <div className="tabs">{Object.keys(TABS).map((k) => <button key={k} className={"tab" + (tab === k ? " on" : "")} onClick={() => setTab(k)}>{TABS[k]}</button>)}</div>
      <div className="card out">
        {!cur ? <span className="status">{busy ? "Working on it…" : "Your study pack will appear here."}</span>
          : cur.error ? <span className="err">{cur.error}</span>
          : <>
              <div dangerouslySetInnerHTML={{ __html: md(cur.text) }} />
              {cur.sources?.length > 0 && <><h3>Sources</h3><ul>{cur.sources.map((s) => <li key={s.url}><a href={s.url} target="_blank" rel="noreferrer">{s.title}</a></li>)}</ul></>}
            </>}
      </div>
      <div className="actions"><button onClick={download} disabled={!Object.values(res).some((r) => r?.text)}>Download as Markdown</button></div>
    </div>
  );
}
